function sayUsername(){
    const username = "Игорь";
    const myArray = ["молнии", "радик", "мышь", "семечки"];
    alert(myArray);
    //alert(username + 2 ** 8);   
    console.log(document.title);
    console.log(document.lastModified);
    console.log(document.domain);
    console.log(document.URL);
}
